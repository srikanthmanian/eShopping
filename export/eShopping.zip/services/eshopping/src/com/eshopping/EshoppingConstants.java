
package com.eshopping;



/**
 *  Query names for service "eshopping"
 *  03/19/2014 14:43:01
 * 
 */
public class EshoppingConstants {

    public final static String getProductByIdQueryName = "getProductById";

}
