
package com.eshopping;



/**
 *  Query names for service "eshopping"
 *  03/13/2014 13:21:01
 * 
 */
public class EshoppingConstants {

    public final static String getProductByIdQueryName = "getProductById";

}
