
package com.eshopping;



/**
 *  Query names for service "eshopping"
 *  03/19/2014 11:18:07
 * 
 */
public class EshoppingConstants {


}
