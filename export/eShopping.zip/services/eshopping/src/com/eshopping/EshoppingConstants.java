
package com.eshopping;



/**
 *  Query names for service "eshopping"
 *  03/14/2014 15:52:40
 * 
 */
public class EshoppingConstants {

    public final static String getProductByIdQueryName = "getProductById";

}
