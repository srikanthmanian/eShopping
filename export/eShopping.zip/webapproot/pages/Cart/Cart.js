Application.$controller("CartPageController", ["$scope", "Widgets", "Variables", "Utils",
    function($scope, Widgets, Variables, Utils) {
        "use strict";

    }
]);

Application.$controller("grid1Controller", ["$scope",
    function($scope) {
        "use strict";
    }
]);