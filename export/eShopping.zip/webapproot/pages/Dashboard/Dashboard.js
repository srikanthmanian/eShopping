Application.$controller("DashboardPageController", ["$scope", "Widgets", function ($scope, Widgets) {
	"use strict";

}]);

Application.$controller("grid1Controller", ["$scope",
	function($scope) {
		"use strict";
	}
]);

Application.$controller("loginDialogController", ["$scope",
	function($scope) {
		"use strict";
	}
]);