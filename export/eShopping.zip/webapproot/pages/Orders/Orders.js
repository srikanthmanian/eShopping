Application.$controller("OrdersPageController", ["$scope", "Widgets", function ($scope, Widgets) {
	"use strict";

}]);