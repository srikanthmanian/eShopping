Application.$controller("ProductPageController", ["$scope", "Widgets", "Variables", "Utils",
    function($scope, Widgets, Variables, Utils) {
        "use strict";

    }
]);