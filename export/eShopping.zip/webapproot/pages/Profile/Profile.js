Application.$controller("ProfilePageController", ["$scope", "Widgets", function ($scope, Widgets) {
	"use strict";

}]);